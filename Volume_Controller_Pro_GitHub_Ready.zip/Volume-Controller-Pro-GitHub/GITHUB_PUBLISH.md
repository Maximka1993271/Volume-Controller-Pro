# Publish this project to GitHub

The project is prepared for a repository named `Volume-Controller-Pro`. A GitHub repository must be created under your account before the first push.

1. Open https://github.com/new.
2. Repository name: `Volume-Controller-Pro`.
3. Choose **Public** to publish the source openly, or **Private** to keep it restricted. Do not select the options that add a README, `.gitignore`, or license; those files are already prepared locally.
4. On your computer, extract this project ZIP and open a terminal in the extracted project folder. Make sure `manifest.json` and `README.md` are directly in that folder.
5. Run the following commands, replacing `<YOUR_GITHUB_USERNAME>` with your account name:

```bash
git init -b main
git add .
git commit -m "Initial release: Volume Controller Pro 4.7.90"
git remote add origin https://github.com/<YOUR_GITHUB_USERNAME>/Volume-Controller-Pro.git
git push -u origin main
```

Git may ask you to authenticate. Use GitHub's approved browser/device sign-in or a configured credential manager; do not paste access tokens into this document or commit them to the repository.

Before publishing, choose an appropriate license if you intend to allow others to reuse or distribute the code. No `LICENSE` file is included because no license choice was specified.
