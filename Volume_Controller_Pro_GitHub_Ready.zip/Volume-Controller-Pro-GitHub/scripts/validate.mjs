import { existsSync, readFileSync, readdirSync } from 'node:fs';
import { join, relative } from 'node:path';
import { spawnSync } from 'node:child_process';

const root = process.cwd();
const errors = [];
const pass = (message) => console.log(`PASS ${message}`);
const fail = (message) => errors.push(message);

function readJson(file) {
  try {
    return JSON.parse(readFileSync(join(root, file), 'utf8'));
  } catch (error) {
    fail(`Invalid JSON ${file}: ${error.message}`);
    return null;
  }
}

const manifest = readJson('manifest.json');
const jsonFiles = ['manifest.json'];
for (const dir of ['lang', '_locales']) {
  if (!existsSync(join(root, dir))) {
    fail(`Missing directory: ${dir}`);
    continue;
  }
  const walk = (current) => {
    for (const entry of readdirSync(join(root, current), { withFileTypes: true })) {
      const rel = join(current, entry.name);
      if (entry.isDirectory()) walk(rel);
      else if (entry.isFile() && entry.name.endsWith('.json')) jsonFiles.push(rel);
    }
  };
  walk(dir);
}

for (const file of [...new Set(jsonFiles)]) {
  const value = readJson(file);
  if (value !== null) pass(`JSON ${file}`);
}

const jsFiles = ['popup.js', 'background.js', 'content.js', 'offscreen.js'];
for (const file of jsFiles) {
  if (!existsSync(join(root, file))) {
    fail(`Missing JavaScript file: ${file}`);
    continue;
  }
  const result = spawnSync(process.execPath, ['--check', file], { cwd: root, encoding: 'utf8' });
  if (result.status !== 0) fail(`JavaScript syntax error in ${file}: ${(result.stderr || result.stdout).trim()}`);
  else pass(`JavaScript syntax ${file}`);
}

for (const locale of ['ru', 'en', 'uk']) {
  const file = `lang/${locale}.json`;
  if (!existsSync(join(root, file))) fail(`Missing UI locale: ${file}`);
}
const localeObjects = ['ru', 'en', 'uk'].map((locale) => ({ locale, values: readJson(`lang/${locale}.json`) }));
if (localeObjects.every((x) => x.values && typeof x.values === 'object' && !Array.isArray(x.values))) {
  const baseKeys = Object.keys(localeObjects[0].values).sort();
  for (const { locale, values } of localeObjects.slice(1)) {
    const keys = Object.keys(values).sort();
    const missing = baseKeys.filter((key) => !Object.hasOwn(values, key));
    const extra = keys.filter((key) => !Object.hasOwn(localeObjects[0].values, key));
    if (missing.length || extra.length) fail(`Locale keys differ for ${locale}; missing: ${missing.join(', ') || 'none'}; extra: ${extra.join(', ') || 'none'}`);
  }
  if (!errors.some((x) => x.startsWith('Locale keys differ'))) pass(`UI locale key parity (${baseKeys.length} keys in RU / EN / UK)`);
}

if (manifest) {
  if (manifest.manifest_version !== 3) fail('manifest.json must use Manifest V3');
  if (manifest.version !== '4.7.90') fail(`Expected manifest version 4.7.90, got ${manifest.version}`);
  for (const file of ['popup.html', 'background.js', 'offscreen.html', 'offscreen.js', 'popup.js', 'popup.css']) {
    if (!existsSync(join(root, file))) fail(`Manifest-related resource missing: ${file}`);
  }
  for (const [size, iconPath] of Object.entries(manifest.icons ?? {})) {
    if (!existsSync(join(root, iconPath))) fail(`Icon ${size} missing: ${iconPath}`);
  }
  if (existsSync(join(root, 'Readme/Readme.md'))) pass('Detailed audit present at Readme/Readme.md');
  else fail('Missing detailed audit: Readme/Readme.md');
}

if (errors.length) {
  console.error(`\n${errors.length} validation error(s):`);
  for (const error of errors) console.error(`- ${error}`);
  process.exitCode = 1;
} else {
  console.log('\nAll static validation checks passed. Manual Edge audio-capture testing is still required.');
}
